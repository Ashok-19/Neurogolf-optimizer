#!/usr/bin/env python3
from pathlib import Path
import numpy as np, onnx
from onnx import helper, TensorProto, numpy_helper
ROOT=Path(__file__).resolve().parents[3]; TASK=ROOT/'tasks/task382'
def init(n,a):return numpy_helper.from_array(np.asarray(a),name=n)
def build(path):
 N=[];I=[]
 def n(op,ins,outs,**kw):N.append(helper.make_node(op,ins,outs,**kw))
 s2=np.zeros(10,np.float32);s2[2]=1;s8=np.zeros(10,np.float32);s8[8]=1
 # shift-right bank: output[k,j]=source[j-k]
 W=np.zeros((5,1,1,5),np.uint8)
 for k in range(5): W[k,0,0,4-k]=1
 I += [init('s2',s2),init('s8',s8),init('ones',np.ones(30,np.float32)),init('z',np.array(0,np.float32)),init('one',np.array(1,np.float32)),
       init('zi64',np.array(0,np.int64)),init('axis0',np.array(0,np.int32)),init('shiftids',np.arange(5,dtype=np.int32).reshape(5,1)),
       init('rev',np.arange(19,-1,-1,dtype=np.int64)),init('idx20',np.arange(20,dtype=np.int64)),init('Wshift',W),
       init('xs',np.array(1,np.float32)),init('ws',np.array(1,np.float32)),init('ys',np.array(1,np.float32)),init('zu8',np.array(0,np.uint8)),
       init('sh1',np.array([1,1,1,20],np.int64)),init('sh5',np.array([5,20],np.int64)),
       init('shA',np.array([1,7,20,1],np.int64)),init('shB',np.array([1,7,1,20],np.int64)),
       init('sh3',np.array(3,np.uint8)),init('sh1u',np.array(1,np.uint8)),
       init('codes',np.arange(1,11,dtype=np.uint8).reshape(1,10,1,1))]
 # Four compact 1-D color count vectors.
 n('Einsum',['input','s2','ones'],['r2x'],equation='nchw,c,w->nh');n('Gather',['r2x','idx20'],['r2'],axis=1)
 n('Einsum',['input','s8','ones'],['r8x'],equation='nchw,c,w->nh');n('Gather',['r8x','idx20'],['r8'],axis=1)
 n('Einsum',['input','s2','ones'],['c2x'],equation='nchw,c,h->nw');n('Gather',['c2x','idx20'],['c2'],axis=1)
 n('Einsum',['input','s8','ones'],['c8x'],equation='nchw,c,h->nw');n('Gather',['c8x','idx20'],['c8'],axis=1)
 n('ReduceMax',['r8'],['r8m'],axes=[1],keepdims=0);n('Greater',['r8m','one'],['horizontal'])
 for src,out in [('r2','r2b'),('r8','r8b'),('c2','c2b'),('c8','c8b')]:n('Greater',[src,'z'],[out]);n('Cast',[out],[out+'u'],to=TensorProto.UINT8)
 n('Where',['horizontal','c8bu','r8bu'],['source'])
 n('Where',['horizontal','r2bu','c2bu'],['event'])
 n('Where',['horizontal','c2bu','r2bu'],['edge'])
 # Physical side flags.
 n('ArgMax',['r8'],['cre'],axis=1,keepdims=0);n('ArgMax',['c8'],['cce'],axis=1,keepdims=0)
 n('ArgMax',['c2'],['rce'],axis=1,keepdims=0);n('ArgMax',['r2'],['rre'],axis=1,keepdims=0)
 n('Where',['horizontal','cre','cce'],['ce']);n('Where',['horizontal','rce','rre'],['re'])
 n('Greater',['ce','zi64'],['chigh']);n('Greater',['re','zi64'],['rhigh'])
 # Prefix shift, choosing the correct physical depth direction.
 n('Cast',['event'],['ei'],to=TensorProto.INT32)
 n('CumSum',['ei','axis0'],['sf'],axis=1 if False else None)
 # remove invalid attr axis and use axis input; CumSum axis input axis0 applies dim0, but event [1,30]. Squeeze first.
 N.pop(); n('Squeeze',['ei'],['e1'],axes=[0]); n('CumSum',['e1','axis0'],['sf'])
 n('CumSum',['e1','axis0'],['sr'],reverse=1);n('Where',['chigh','sr','sf'],['shift'])
 n('Unsqueeze',['shift'],['shift2'],axes=[0]);n('Equal',['shiftids','shift2'],['Db']);n('Cast',['Db'],['D'],to=TensorProto.UINT8)
 # Canonicalize lateral direction, create all five shifted source vectors with one tiny QLinearConv, then restore direction.
 n('Gather',['source','rev'],['srev'],axis=1);n('Where',['rhigh','srev','source'],['scan'])
 n('Reshape',['scan','sh1'],['scan4'])
 n('QLinearConv',['scan4','xs','zu8','Wshift','ws','zu8','ys','zu8'],['S4'],kernel_shape=[1,5],pads=[0,4,0,0])
 n('Reshape',['S4','sh5'],['Scan']);n('Gather',['Scan','rev'],['Sback'],axis=1);n('Where',['rhigh','Sback','Scan'],['S'])
 # Rank factors and code scaling by cheap bit shifts.
 n('Where',['horizontal','D','S'],['CA']);n('Where',['horizontal','S','D'],['CB'])
 n('BitShift',['CB','sh3'],['CB8'],direction='LEFT')
 n('Where',['horizontal','event','edge'],['RA0']);n('Where',['horizontal','edge','event'],['RB0']);n('BitShift',['RB0','sh1u'],['RB2'],direction='LEFT')
 # Dynamic valid-grid factors.
 n('ReduceMax',['input'],['rvfx'],axes=[1,3],keepdims=0);n('ReduceMax',['input'],['cvfx'],axes=[1,2],keepdims=0)
 n('Gather',['rvfx','idx20'],['rvf'],axis=1);n('Gather',['cvfx','idx20'],['cvf'],axis=1)
 n('Greater',['rvf','z'],['rvb']);n('Greater',['cvf','z'],['cvb']);n('Cast',['rvb'],['rv'],to=TensorProto.UINT8);n('Cast',['cvb'],['cv'],to=TensorProto.UINT8)
 n('Where',['rvb','CA','zu8'],['CAv']);n('Where',['cvb','CB8','zu8'],['CBv'])
 n('Concat',['CAv','RA0','rv'],['A7'],axis=0);n('Concat',['CBv','RB2','cv'],['B7'],axis=0)
 n('Gather',['B7','rev'],['B7r'],axis=1);n('Reshape',['A7','shA'],['A4']);n('Reshape',['B7r','shB'],['B4'])
 n('QLinearConv',['A4','xs','zu8','B4','ws','zu8','ys','zu8'],['code'],kernel_shape=[1,20],pads=[0,19,10,29])
 n('Equal',['code','codes'],['output'])
 G=helper.make_graph(N,'task382_lean',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,10,30,30])],[helper.make_tensor_value_info('output',TensorProto.BOOL,[1,10,30,30])],I)
 M=helper.make_model(G,opset_imports=[helper.make_opsetid('',12)],ir_version=8,producer_name='ng-structural-rewrite')
 onnx.checker.check_model(M);onnx.save(M,path);print('saved',len(N),sum(numpy_helper.to_array(x).size for x in I))
if __name__=='__main__':build(TASK/'work2/candidate20.onnx')
