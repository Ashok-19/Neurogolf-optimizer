#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import onnx
from onnx import helper, TensorProto, numpy_helper

ROOT=Path(__file__).resolve().parents[3]
TASK=ROOT/'tasks/task148'

def init(name,arr):
    return numpy_helper.from_array(np.asarray(arr),name=name)

def build(path:Path):
    red=np.zeros(10,np.float32); red[2]=1
    cyan=np.zeros(10,np.float32); cyan[8]=1
    inits=[
      init('redsel',red), init('cyansel',cyan),
      init('colsplus30f',np.arange(1,31,dtype=np.float32)), init('cols30f',np.arange(30,dtype=np.float32)),
      init('idx24',np.arange(24,dtype=np.int64)), init('idx10',np.arange(10,dtype=np.int64)), init('idx14tail',np.arange(10,24,dtype=np.int64)),
      init('coords10',np.arange(10,dtype=np.int64)), init('cols12',np.arange(12,dtype=np.uint8)), init('cols12f',np.arange(12,dtype=np.float32)),
      init('zero_i64',np.array(0,np.int64)), init('zero_f',np.array(0,np.float32)), init('one_f',np.array(1,np.float32)),
      init('zero_u8',np.array(0,np.uint8)), init('one_u8',np.array(1,np.uint8)),
      init('two_u8',np.array(2,np.uint8)), init('four_u8',np.array(4,np.uint8)),
      init('eight_u8',np.array(8,np.uint8)), init('twelve_u8',np.array(12,np.uint8)),
      init('ninetynine_u8',np.array(99,np.uint8)),
      init('starts_rowtail',np.array([0,0,10,1],np.int64)), init('ends_rowtail',np.array([1,1,24,2],np.int64)),
      init('starts_colvalid',np.array([0,0,0,0],np.int64)), init('ends_colvalid',np.array([1,1,1,12],np.int64)),
      init('pads2d',np.array([0,0,6,18],np.int64)),
      init('colorids',np.array([1,99,2,99,4,99,99,99,8,99],np.uint8).reshape(1,10,1,1)),
      init('zeros24b',np.zeros(24,np.bool_)),
    ]
    N=[]
    def node(op,ins,outs,**kw): N.append(helper.make_node(op,ins,outs,**kw))

    # One-dimensional portal and marker summaries. Red rows contain a single red cell,
    # so the column moment is zero on the left portal and positive on the right portal.
    node('Einsum',['input','redsel','colsplus30f'],['redcode30'],equation='nchw,c,w->h')
    node('Einsum',['input','cyansel','cols30f'],['markermoment30'],equation='nchw,c,w->h')
    node('Gather',['redcode30','idx24'],['redcode'],axis=0)
    node('Gather',['markermoment30','idx10'],['markerf'],axis=0)
    node('Greater',['redcode','zero_f'],['redpresent'])
    node('Greater',['redcode','one_f'],['rightrows'])
    node('Equal',['redcode','one_f'],['leftrows'])
    node('Gather',['leftrows','idx10'],['lefttop'],axis=0)
    node('Gather',['rightrows','idx10'],['righttop'],axis=0)
    node('Greater',['markerf','zero_f'],['marker'])
    node('Cast',['markerf'],['markercol'],to=TensorProto.UINT8)

    # Determine which portal is the source, then translate all marked source rows to
    # their destination rows. All geometry stays scalar or one-dimensional here.
    node('And',['lefttop','marker'],['sourceleftrows'])
    node('And',['righttop','marker'],['sourcerightrows'])
    node('Cast',['sourceleftrows'],['sourceleftu8'],to=TensorProto.UINT8)
    node('ReduceMax',['sourceleftu8'],['sourceleftflag'],axes=[0],keepdims=0)
    node('Greater',['sourceleftflag','zero_u8'],['sourceleft'])
    node('Cast',['leftrows'],['leftu8'],to=TensorProto.UINT8)
    node('Cast',['rightrows'],['rightu8'],to=TensorProto.UINT8)
    node('ArgMax',['leftu8'],['leftstart'],axis=0,keepdims=0)
    node('ArgMax',['rightu8'],['rightstart'],axis=0,keepdims=0)
    node('Sub',['rightstart','leftstart'],['shiftlr'])
    node('Sub',['leftstart','rightstart'],['shiftrl'])
    node('Where',['sourceleft','shiftlr','shiftrl'],['shift'])
    node('Add',['coords10','shift'],['shiftedrows'])
    node('Where',['marker','shiftedrows','zero_i64'],['destidx'])
    node('ScatterElements',['zeros24b','destidx','marker'],['destrows'],axis=0)
    node('Gather',['destrows','idx10'],['desttop'],axis=0)
    node('Gather',['destrows','idx14tail'],['desttail'],axis=0)

    # Valid width and tail rows are read from guaranteed-background cells.
    node('Slice',['input','starts_colvalid','ends_colvalid'],['colvalidf'])
    node('Slice',['input','starts_rowtail','ends_rowtail'],['rowtailf'])
    node('Squeeze',['colvalidf'],['colvalid'],axes=[0,1,2])
    node('Squeeze',['rowtailf'],['rowtail'],axes=[0,1,3])
    node('Cast',['colvalid'],['colvalidb'],to=TensorProto.BOOL)
    node('Cast',['rowtail'],['rowtailb'],to=TensorProto.BOOL)
    node('Cast',['colvalidb'],['basecols'],to=TensorProto.UINT8)

    # Render the source rows: yellow marker, cyan trail to its portal, and any
    # destination row that happens to be in the top section.
    node('Unsqueeze',['markercol'],['markercol2'],axes=[1])
    node('Unsqueeze',['marker'],['marker2'],axes=[1])
    node('Unsqueeze',['sourceleftrows'],['sourceleft2'],axes=[1])
    node('Unsqueeze',['sourcerightrows'],['sourceright2'],axes=[1])
    node('Unsqueeze',['desttop'],['desttop2'],axes=[1])
    node('Where',['sourceleft2','markercol2','zero_u8'],['leftinner'])
    node('Where',['desttop2','twelve_u8','leftinner'],['leftlimit'])
    node('Where',['sourceright2','markercol2','ninetynine_u8'],['rightlimit'])
    node('Less',['cols12','leftlimit'],['leftfill'])
    node('Greater',['cols12','rightlimit'],['rightfill'])
    node('Or',['leftfill','rightfill'],['fillraw'])
    node('And',['fillraw','colvalidb'],['fill'])
    node('Where',['fill','eight_u8','basecols'],['topfill'])
    node('Equal',['cols12','markercol2'],['markereq'])
    node('And',['markereq','marker2'],['markercells'])
    node('Where',['markercells','four_u8','topfill'],['labeltop'])

    # Render the destination rows and ordinary background rows in the tail.
    node('Unsqueeze',['desttail'],['desttail2'],axes=[1])
    node('Unsqueeze',['rowtailb'],['rowtail2'],axes=[1])
    node('Where',['desttail2','eight_u8','one_u8'],['tailrowvalue'])
    node('Where',['rowtail2','tailrowvalue','zero_u8'],['innertail'])
    node('Where',['colvalidb','innertail','zero_u8'],['labeltail'])
    node('Concat',['labeltop','labeltail'],['label24'],axis=0)

    # Draw both red portal columns from their row-wise column moments, then pad the
    # valid 24x12 canvas and convert label IDs to a one-hot output.
    node('Sub',['redcode','one_f'],['redcolf'])
    node('Unsqueeze',['redcolf'],['redcol2'],axes=[1])
    node('Equal',['redcol2','cols12f'],['redcells'])
    node('Where',['redcells','two_u8','label24'],['labelred'])
    node('Pad',['labelred','pads2d'],['label30'])
    node('Equal',['label30','colorids'],['output'])

    graph=helper.make_graph(N,'task148_portal_moments',
      [helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,10,30,30])],
      [helper.make_tensor_value_info('output',TensorProto.BOOL,[1,10,30,30])],inits)
    model=helper.make_model(graph,opset_imports=[helper.make_opsetid('',12)],producer_name='ng-structural-rewrite')
    onnx.checker.check_model(model)
    onnx.save(model,path)
    print('saved',path,'nodes',len(N),'params',sum(np.asarray(numpy_helper.to_array(x)).size for x in inits))

if __name__=='__main__':
    build(TASK/'work/candidate.onnx')
