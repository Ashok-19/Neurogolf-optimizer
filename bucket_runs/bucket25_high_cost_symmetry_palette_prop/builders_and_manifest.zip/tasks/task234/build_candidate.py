#!/usr/bin/env python3
from __future__ import annotations
import json, random, sys, importlib.util
from pathlib import Path
import numpy as np
import onnx
from onnx import helper, TensorProto, numpy_helper

ROOT=Path(__file__).resolve().parents[3]
TASK=ROOT/'tasks/task234'

def solve_numpy(grid):
    a=np.asarray(grid,dtype=np.int64)
    H,W=a.shape
    colors=sorted(int(x) for x in np.unique(a) if x)
    assert len(colors)==2
    objs=[]
    for color in colors:
        rr,cc=np.where(a==color)
        objs.append(dict(color=color,pix=len(rr),r0=int(rr.min()),r1=int(rr.max()),c0=int(cc.min()),c1=int(cc.max())))
    armed=[o for o in objs if o['pix'] < (o['r1']-o['r0']+1)*(o['c1']-o['c0']+1)]
    assert len(armed)==1
    arm=armed[0]; pure=objs[1-objs.index(arm)]
    bh=arm['r1']-arm['r0']+1; bw=arm['c1']-arm['c0']+1
    top=pure['r1']<arm['r0']; bottom=pure['r0']>arm['r1']; left=pure['c1']<arm['c0']; right=pure['c0']>arm['c1']
    vertical=top or bottom
    extent=((arm['pix']-bh)//(bw-1)) if vertical else ((arm['pix']-bw)//(bh-1))
    rh=extent if vertical else bh; rw=bw if vertical else extent
    rs=arm['r1']-rh+1 if bottom else arm['r0']
    re=arm['r0']+rh-1 if top else arm['r1']
    cs=arm['c1']-rw+1 if right else arm['c0']
    ce=arm['c0']+rw-1 if left else arm['c1']
    out=np.zeros_like(a)
    out[pure['r0']:pure['r1']+1,pure['c0']:pure['c1']+1]=pure['color']
    out[rs:re+1,cs:ce+1]=arm['color']
    return out.tolist()

def test_numpy(nfresh=3000):
    d=json.loads((TASK/'task.json').read_text())
    pairs=d['train']+d['test']+d['arc-gen']
    for i,p in enumerate(pairs):
        got=solve_numpy(p['input'])
        if got!=p['output']: raise AssertionError(('bundled',i))
    sys.path.insert(0,str(ROOT/'ARC-GEN'))
    spec=importlib.util.spec_from_file_location('g234',TASK/'arcgen_task.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
    seen={str(p['input']) for p in pairs}; done=0
    for i in range(10000):
        if done>=nfresh: break
        random.seed(10000+i);p=g.generate()
        if str(p['input']) in seen: continue
        seen.add(str(p['input']))
        if solve_numpy(p['input'])!=p['output']: raise AssertionError(('fresh',i,p))
        done+=1
    print('numpy exact',len(pairs),done)

def init(name,arr): return numpy_helper.from_array(np.asarray(arr),name=name)

def build(path:Path):
    B=32.0
    cf=np.zeros(30,np.float32); cr=np.zeros(30,np.float32)
    for i in range(20):
        cf[i]=B**i; cr[i]=B**(19-i)
    inits=[
      init('cf',cf),init('cr',cr),init('invlnb',np.array(1/np.log(B),np.float32)),init('eps',np.array(1e-3,np.float32)),
      init('i19',np.array(19,np.int32)),init('zero_i32',np.array(0,np.int32)),init('one_i32',np.array(1,np.int32)),init('one_i64',np.array(1,np.int64)),
      init('zero_u8',np.array(0,np.uint8)),init('one_u8',np.array(1,np.uint8)),
      init('zero_f',np.array(0,np.float32)),init('idx10',np.arange(10,dtype=np.int64)),init('idx10u8',np.arange(10,dtype=np.uint8)),
      init('depth10',np.array(10,np.int64)),init('ohv',np.array([0.,1.],np.float32)),
      init('coords30',np.arange(30,dtype=np.int32)),
      init('basew',np.array([[[1,0,0,0,0,0,0,0,0,0]]],np.float16)),
    ]
    N=[]
    def node(op,ins,outs,**kw):N.append(helper.make_node(op,ins,outs,**kw))
    # Total pixels and two non-background color indices.
    node('ReduceSum',['input'],['pix10'],axes=[0,2,3],keepdims=0)
    node('Greater',['pix10','zero_f'],['present'])
    node('Greater',['idx10u8','zero_u8'],['nonbg'])
    node('And',['present','nonbg'],['used'])
    node('Cast',['used'],['usedu8'],to=TensorProto.UINT8)
    node('ArgMax',['usedu8'],['c0'],axis=0,keepdims=0)
    node('ArgMax',['usedu8'],['c1'],axis=0,keepdims=0,select_last_index=1)
    node('Unsqueeze',['c0'],['c0v'],axes=[0]);node('Unsqueeze',['c1'],['c1v'],axes=[0])
    node('Concat',['c0v','c1v'],['cidx'],axis=0)
    node('OneHot',['cidx','depth10','ohv'],['sel2'],axis=-1)
    node('Gather',['pix10','cidx'],['pix2'],axis=0)
    node('Cast',['pix2'],['pix2i'],to=TensorProto.INT32)
    # Compact max/min coordinates for each selected color.
    node('Einsum',['input','sel2','cf'],['ermax'],equation='nchw,kc,h->k')
    node('Einsum',['input','sel2','cr'],['ermin'],equation='nchw,kc,h->k')
    node('Einsum',['input','sel2','cf'],['ecmax'],equation='nchw,kc,w->k')
    node('Einsum',['input','sel2','cr'],['ecmin'],equation='nchw,kc,w->k')
    def decode_max(src,out):
        node('Log',[src],[out+'lg']);node('Mul',[out+'lg','invlnb'],[out+'q']);node('Add',[out+'q','eps'],[out+'qe']);node('Floor',[out+'qe'],[out+'ff']);node('Cast',[out+'ff'],[out],to=TensorProto.INT32)
    decode_max('ermax','r1');decode_max('ecmax','c1x')
    decode_max('ermin','rr');decode_max('ecmin','cc')
    node('Sub',['i19','rr'],['r0']);node('Sub',['i19','cc'],['c0x'])
    # Actual grid extents from all one-hot cells.
    node('Einsum',['input','cf'],['grem'],equation='nchw,h->n')
    node('Einsum',['input','cf'],['gcem'],equation='nchw,w->n')
    decode_max('grem','grid_r1arr');decode_max('gcem','grid_c1arr')
    node('Squeeze',['grid_r1arr'],['grid_r1'],axes=[0]);node('Squeeze',['grid_c1arr'],['grid_c1'],axes=[0])
    # Bboxes and armed-color selector.
    node('Sub',['r1','r0'],['bh0']);node('Add',['bh0','one_i32'],['bh'])
    node('Sub',['c1x','c0x'],['bw0']);node('Add',['bw0','one_i32'],['bw'])
    node('Mul',['bh','bw'],['area'])
    node('Less',['pix2i','area'],['armed2'])
    node('Cast',['armed2'],['armed2u8'],to=TensorProto.UINT8)
    node('ArgMax',['armed2u8'],['ai'],axis=0,keepdims=0)
    node('Sub',['one_i64','ai'],['pi'])
    # Gather arm/pure scalar fields.
    for src in ['pix2i','r0','r1','c0x','c1x','bh','bw']:
        node('Gather',[src,'ai'],['a_'+src],axis=0);node('Gather',[src,'pi'],['p_'+src],axis=0)
    node('Gather',['cidx','ai'],['acol'],axis=0);node('Gather',['cidx','pi'],['pcol'],axis=0)
    node('Cast',['acol'],['acolu8'],to=TensorProto.UINT8);node('Cast',['pcol'],['pcolu8'],to=TensorProto.UINT8)
    # Direction and true body extent of the armed component.
    node('Less',['p_r1','a_r0'],['top']);node('Greater',['p_r0','a_r1'],['bottom'])
    node('Less',['p_c1x','a_c0x'],['left']);node('Greater',['p_c0x','a_c1x'],['right'])
    node('Or',['top','bottom'],['vertical'])
    node('Sub',['a_pix2i','a_bh'],['vnum']);node('Sub',['a_pix2i','a_bw'],['hnum'])
    node('Sub',['a_bw','one_i32'],['bwm1']);node('Sub',['a_bh','one_i32'],['bhm1'])
    node('Where',['vertical','vnum','hnum'],['rectnum']);node('Where',['vertical','bwm1','bhm1'],['rectden'])
    node('Div',['rectnum','rectden'],['extent'])
    node('Where',['vertical','extent','a_bh'],['rh']);node('Where',['vertical','a_bw','extent'],['rw'])
    node('Sub',['rh','one_i32'],['rhm1']);node('Sub',['rw','one_i32'],['rwm1'])
    node('Sub',['a_r1','rhm1'],['rs_bottom']);node('Add',['a_r0','rhm1'],['re_top'])
    node('Sub',['a_c1x','rwm1'],['cs_right']);node('Add',['a_c0x','rwm1'],['ce_left'])
    node('Where',['bottom','rs_bottom','a_r0'],['ars']);node('Where',['top','re_top','a_r1'],['are'])
    node('Where',['right','cs_right','a_c0x'],['acs']);node('Where',['left','ce_left','a_c1x'],['ace'])
    # Three low-rank rectangles: valid background, stationary body, moved body.
    for x in ['zero_i32','p_r0','ars','grid_r1','p_r1','are','p_c0x','acs','grid_c1','p_c1x','ace']:
        node('Unsqueeze',[x],[x+'v'],axes=[0])
    node('Concat',['zero_i32v','p_r0v','arsv'],['rstarts'],axis=0)
    node('Concat',['grid_r1v','p_r1v','arev'],['rends'],axis=0)
    node('Concat',['zero_i32v','p_c0xv','acsv'],['cstarts'],axis=0)
    node('Concat',['grid_c1v','p_c1xv','acev'],['cends'],axis=0)
    node('Unsqueeze',['rstarts'],['rstarts2'],axes=[1]);node('Unsqueeze',['rends'],['rends2'],axes=[1])
    node('Unsqueeze',['cstarts'],['cstarts2'],axes=[1]);node('Unsqueeze',['cends'],['cends2'],axes=[1])
    node('GreaterOrEqual',['coords30','rstarts2'],['rge']);node('LessOrEqual',['coords30','rends2'],['rle']);node('And',['rge','rle'],['rowsb'])
    node('GreaterOrEqual',['coords30','cstarts2'],['cge']);node('LessOrEqual',['coords30','cends2'],['cle']);node('And',['cge','cle'],['colsb'])
    node('Cast',['rowsb'],['rows'],to=TensorProto.FLOAT16);node('Cast',['colsb'],['cols'],to=TensorProto.FLOAT16)
    node('Equal',['idx10u8','pcolu8'],['pohb']);node('Equal',['idx10u8','acolu8'],['aohb'])
    node('Cast',['pohb'],['poh'],to=TensorProto.FLOAT16);node('Cast',['aohb'],['aoh'],to=TensorProto.FLOAT16)
    node('Unsqueeze',['poh'],['poh3'],axes=[0,1]);node('Unsqueeze',['aoh'],['aoh3'],axes=[0,1])
    node('Sub',['poh3','basew'],['pw']);node('Sub',['aoh3','basew'],['aw'])
    node('Concat',['basew','pw','aw'],['weights'],axis=1)
    node('Unsqueeze',['rows'],['rowsn'],axes=[0]);node('Unsqueeze',['cols'],['colsn'],axes=[0])
    node('Einsum',['rowsn','colsn','weights'],['output'],equation='nkh,nkw,nkc->nchw')
    graph=helper.make_graph(N,'task234_structural',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,10,30,30])],[helper.make_tensor_value_info('output',TensorProto.FLOAT16,[1,10,30,30])],inits)
    model=helper.make_model(graph,opset_imports=[helper.make_opsetid('',12)],producer_name='ng-structural-rewrite')
    onnx.checker.check_model(model);onnx.save(model,path)
    print('saved',path,'nodes',len(N),'params',sum(np.asarray(numpy_helper.to_array(x)).size for x in inits))

if __name__=='__main__':
    test_numpy()
    build(TASK/'work/candidate.onnx')
